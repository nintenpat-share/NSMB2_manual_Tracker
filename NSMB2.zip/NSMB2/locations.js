window.locations = []
