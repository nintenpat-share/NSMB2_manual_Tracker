window.regions = 
{
  "Title Screen": {
    "connects_to": [
    ],
    "requires": [],
    "starting": true
  }
}