window.items = [
  {
    "count": "5",
    "name": "Progressive Powerup",
    "category": [
      "Powerups"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Mini Mushroom",
    "category": [
      "Powerups"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Mega Mushroom",
    "category": [
      "Powerups"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Super Star",
    "category": [
      "Powerups"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Gold Block",
    "category": [
      "Powerups"
    ],
    "useful": true
  },
  {
    "count": 1,
    "name": "P Switch",
    "category": [
      "Level Objects"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Level-Specific Switches",
    "category": [
      "Level Objects"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "? Switch",
    "category": [
      "Level Objects"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Red Ring",
    "category": [
      "Level Objects"
    ],
    "useful": true
  },
  {
    "count": 1,
    "name": "Gold Ring",
    "category": [
      "Level Objects"
    ],
    "useful": true
  },
  {
    "count": 1,
    "name": "Springboard",
    "category": [
      "Level Objects"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "World 1 Unlock",
    "category": [
      "Worlds"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "World 2 Unlock",
    "category": [
      "Worlds",
      "Starting Worlds"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "World Mushroom Unlock",
    "category": [
      "Worlds"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "World 3 Unlock",
    "category": [
      "Worlds"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "World 4 Unlock",
    "category": [
      "Worlds",
      "Starting Worlds"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "World Flower Unlock",
    "category": [
      "Worlds"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "World 5 Unlock",
    "category": [
      "Worlds",
      "Starting Worlds"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "World 6 Unlock",
    "category": [
      "Worlds"
    ],
    "progression": true
  },
  {
    "count": 8,
    "name": "Progressive World Star Unlock",
    "category": [
      "Worlds",
      "World Star"
    ],
    "progression": true
  },
  {
    "count": "219",
    "name": "Star Coin",
    "category": [
      "Collectibles",
      "Star Coins"
    ],
    "progression_skip_balancing": true
  },
  {
    "count": "24",
    "name": "Moon Coin",
    "category": [
      "Collectibles",
      "Moon Coins"
    ],
    "filler": true
  },
  {
    "count": 1,
    "name": "Pipe Traversal - Up",
    "category": [
      "Pipe Traversal",
      "Abilities"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Pipe Traversal - Down",
    "category": [
      "Pipe Traversal",
      "Abilities"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Pipe Traversal - Left",
    "category": [
      "Pipe Traversal",
      "Abilities"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Pipe Traversal - Right",
    "category": [
      "Pipe Traversal",
      "Abilities"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Door Traversal",
    "category": [
      "Abilities"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Cannon Unlock",
    "category": [
      "Abilities"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Wall Jump",
    "category": [
      "Abilities"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Ground Pound",
    "category": [
      "Abilities"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Climb",
    "category": [
      "Abilities"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Swim",
    "category": [
      "Abilities"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Carry",
    "category": [
      "Abilities"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Reserve Box",
    "category": [
      "Abilities"
    ],
    "useful": true
  },
  {
    "count": "13",
    "name": "Boss Token",
    "category": [
      "Collectibles"
    ],
    "progression_skip_balancing": true
  },
  {
    "count": 1,
    "name": "Luigi",
    "category": [],
    "filler": true
  },
  {
    "count": 1,
    "name": "1-A Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "2-A Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "2-B Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "M-A Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "M-B Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "3-A Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "3-B Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "4-A Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "4-B Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "4-C Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "F-A Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "F-B Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "5-A Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "6-A Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "6-B Unlock",
    "category": [
      "Level Unlocks"
    ],
    "progression": true
  },
  {
    "count": 1,
    "name": "Lakitu Cloud",
    "category": [
      "Level Objects"
    ],
    "progression": true
  },
  {
    "count": 0,
    "name": "OHKO Trap",
    "category": [
      "Traps"
    ],
    "trap": true
  },
  {
    "count": 0,
    "name": "Flip Trap",
    "category": [
      "Traps"
    ],
    "trap": true
  },
  {
    "count": 0,
    "name": "Instruction Manual Trap",
    "category": [
      "Traps"
    ],
    "trap": true
  }
]